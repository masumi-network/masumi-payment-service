# API compatibility matrix (preprod)

Generated 2026-09-18T12:20:09Z. Same endpoints, same bodies; only the optional `forceLayer` field differs.

| Case | forceLayer sent | Layer chosen by the service | State | Tx |
|---|---|---|---|---|
| forceLayer L1 | "L1" | L1 | FundsLocked | `45ad6d4453e24e84…` |
| forceLayer Hydra | "Hydra" | L2 | FundsLocked | `38abe5dc99f94fcf…` |
| forceLayer omitted | null | L2 | FundsLocked | `c2515612d5180e06…` |
