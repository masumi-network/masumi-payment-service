# Identity retention run (preprod, 2026-09-19)

## What was run

1. A fresh Hydra head was opened on preprod (hydra-node 2.4.1) and the payment service was started against it.
2. One agent was registered through `POST /registry` with one KERI-ACDC verification claim. The service minted its registry NFT on preprod: [01a02e927791023a9af3f1ec95bba37157cf0106c285ff1a9d3dff30f96f907b](https://preprod.cardanoscan.io/transaction/01a02e927791023a9af3f1ec95bba37157cf0106c285ff1a9d3dff30f96f907b). The read-back from `GET /registry` is in [registry-agent.json](registry-agent.json).
3. Two purchases for that agent were created with the unchanged `POST /payment` and `POST /purchase` calls, one with `forceLayer: "Hydra"` and one with the field omitted. Both were locked inside the head: [run/cases.json](run/cases.json).
4. A result was submitted on both through `POST /payment/submit-result`; after the unlock time the service collected both inside the head.
5. `20-identity-audit-log.mts` exported the trail. It only reads.
6. The head was closed and fanned out through the service API: close [4b46499d5cf146196d174bdb602fb69b5787cfd328d569b918b9b38f70ce8749](https://preprod.cardanoscan.io/transaction/4b46499d5cf146196d174bdb602fb69b5787cfd328d569b918b9b38f70ce8749), fanout [a6c9a940c5150c9180a8f345a08b8bc7cc327a1e6075976b6cb3b0933eb77bd9](https://preprod.cardanoscan.io/transaction/a6c9a940c5150c9180a8f345a08b8bc7cc327a1e6075976b6cb3b0933eb77bd9). All of the head's Layer 1 transactions are in [l1-anchors.json](l1-anchors.json).

## Identifiers

| Item                                                                 | Value                                                                                                                      |
| -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| Agent identifier (registry NFT: policy id + asset name)              | `67ab0c92c4ac1610895a1c965ee50aba41a8f1513b15240723b3bd0b10e764a51840875ea64a6f723c104c0374ae66fea42dd3a64f21252757000000` |
| Head identifier on chain                                             | `aee0fd263b05ee2d18d32c3d41613501f9f2d005a26d1a9146a514d6`                                                                 |
| Head id in the service database (the `Head` column of the audit log) | `cmu7tb87e0007hsuci6ergm12`                                                                                                |
| Audit log                                                            | 12 rows covering 6 distinct in-head transactions (payment Withdrawn: 6; purchase Withdrawn: 6)                             |

## What the audit log shows

Every row of [AUDIT-LOG.md](AUDIT-LOG.md) is an in-head transaction as recorded on one side: the buyer's purchase or the seller's payment. The 12 rows cover 6 distinct transactions, a lock, a result submission and a collection for each of the two purchases, each seen from both sides. Each row is joined, through fields the product already stores, to the agent identifier above and to the issuer AID, holder AID and credential SAID registered for that agent. On a payment, the agent identifier can also be decoded from the `blockchainIdentifier`, which embeds it together with the selling wallet's signature over the payment terms; the signed terms include the agent identifier.

## Measurements recorded when this note was generated

| Measurement                                                                                                     | Value  |
| --------------------------------------------------------------------------------------------------------------- | ------ |
| Distinct `blockchainIdentifier` values in the audit log whose embedded agent identifier equals the exported one | 2 of 2 |
| `L2 submit-result deferred` lines in the service log of this run                                                | 0      |
| `txHash persistence failed` lines in the service log of this run                                                | 0      |

The service log itself is not published. The first row is reproducible from [audit-log.json](audit-log.json) alone: decompress each `blockchainIdentifier` (hex, LZString), split on ".", and drop the first 64 characters of the first segment.

## What it does not show

- The KERI-ACDC values are the API's documented example values and their OOBI addresses use `example.invalid`, so the credential cannot be resolved or verified. This run shows that the binding and the audit trail survive on Layer 2. It does not show KERI credential verification.
- In-head transactions are not visible on a public explorer. The public anchors are the agent's mint transaction and the head's Layer 1 transactions.
- Preprod only.
