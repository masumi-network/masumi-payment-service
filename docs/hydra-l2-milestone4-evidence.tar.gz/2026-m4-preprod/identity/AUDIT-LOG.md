# Milestone 4: L2 audit log with agent identity (preprod)

Generated 2026-09-19T04:48:40.331Z. Every row is an in-head (L2) transaction the payment service built, joined to the agent it paid through fields the product already stores. No identity code was changed to produce this.

| Side | L2 tx | Head | Request state | Agent identifier (registry NFT) | Agent | KERI method | Issuer AID | Holder AID | Credential SAID |
|---|---|---|---|---|---|---|---|---|---|
| purchase | `e6d09b83d35f5cbf…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| purchase | `d54dda9d6dbefb54…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| purchase | `650f39d8da969f14…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| purchase | `d9f4adbd60042bc9…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| purchase | `c6ca8819ed8bf57d…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| purchase | `c96c31149fa2ae8d…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `e6d09b83d35f5cbf…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `d54dda9d6dbefb54…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `650f39d8da969f14…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `d9f4adbd60042bc9…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `c6ca8819ed8bf57d…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |
| payment | `c96c31149fa2ae8d…` | `cmu7tb87…` | Withdrawn | `67ab0c92c4ac1610895a…` | M4 Preprod Test Agent | KERI-ACDC | `EIaIeKvfBLmZf3wfqB0oR1uM5n8m9k2pQ7rT4sV1wX3y` | `EBcd1ef2gh3ij4kl5mn6op7qr8st9uv0wx1yz2ab3cd4` | `EHpH79tPZoSl7VJZ7xMi3JWF4rH9wZ2ntGvKABd9N14z` |

Reproduce any row: `GET /api/v1/purchase` or `GET /api/v1/payment` returns `agentIdentifier`, `CurrentTransaction.layer` and `CurrentTransaction.hydraHeadId`; `GET /api/v1/registry?network=Preprod` returns the same agent with its `verifications`.
