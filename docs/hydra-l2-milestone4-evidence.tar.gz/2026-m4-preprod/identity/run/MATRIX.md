# API compatibility matrix (preprod)

Generated 2026-09-19T03:37:39Z. Same endpoints, same bodies; only the optional `forceLayer` field differs.

| Case | forceLayer sent | Layer chosen by the service | State | Tx |
|---|---|---|---|---|
| forceLayer Hydra | "Hydra" | L2 | FundsLocked | `e6d09b83d35f5cbf…` |
| forceLayer omitted | null | L2 | FundsLocked | `d9f4adbd60042bc9…` |
