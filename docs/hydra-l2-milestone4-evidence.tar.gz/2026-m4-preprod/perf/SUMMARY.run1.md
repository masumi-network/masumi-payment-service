# Milestone 4: performance retention (preprod)

Measured during the Milestone 4 integration runs on hydra-node 2.4.1, same method as the Milestone 3 report.

| Metric | Target | Measured |
|---|---|---|
| Per-payment finality p50 | < 500 ms | 41.1 ms |
| Per-payment finality p95 | — | 52.6 ms |
| Sequential run confirmed | — | 200/200 |
| Transaction cost reduction | 95 % | see COST.md |

Raw results: `raw-latest/result.json`, escrow lifecycles: `escrow-latest/SUMMARY.md`.
