# Escrow bench — run 2 (fresh head f5cf7f97…) — Phase A aborted, no lifecycles completed

Run directly (not through `replicate-benchmark.sh escrow`'s wrapper, which pipes the bench's
stdout through `grep -E "Phase [ABC] done|RESULT|FATAL"` and discards everything else) so the
full, unfiltered log could be captured. Full log: `escrow-run2-full.log` (this directory).

Funding performed manually first (same values `cmd_escrow` uses): buyer
`addr_test1qpx9yesfls03wgndzhlky004w4hxufdmcfyqxrpermkmjna44xhhddygcelx5v0qlp7gyxl6acpefensvr5appn52h7qu0fszr`
funded 50 ADA in-head, seller
`addr_test1qpppfm065ajl3p2sr7wqm9v39dhpupw26jhg0vcnuv88ftu768xa55srajh7qw2x0qthp5xd7zzyv37ve3x7q74gh7hssrnkwz`
funded 20 ADA in-head. Then:
```
DATABASE_URL=postgresql://postgres:testpass@localhost:5434/masumi_hydra_test?schema=public \
pnpm exec tsx hydra-l2-flow/bench-escrow-e2e.mts 10
```

## Outcome

**All 10/10 lock attempts hit the service's new "ambiguous" path — 0/10 registered as locked by
the bench's strict metric. `main()` threw and the process exited non-zero. No `result.json` /
`SUMMARY.md` / `RESULT:` line was produced** — the bench writes those only at the very end of
`main()`, after Phase C, and it never got past Phase A.

```
[escrow-bench] 14:11:39 Phase A done: 0/10 locked in 271.6s (0.00/s), script UTxOs 0→9
[escrow-bench] FATAL Error: no locks succeeded — aborting
```

Grep counts on the full log (`escrow-run2-full.log`):

| pattern | count |
|---|---|
| `txHash persistence failed` (run-1's symptom string) | **0** |
| `L2 funds-lock outcome ambiguous` (10 events × 2 log lines each: the bench's own error-detail hook + winston's own line) | 20 |
| `was not confirmed within 30000ms` | 9 |
| `ConwayMempoolFailure` | 1 |
| `L2 funds-lock failed before submit reservation` | 0 |

So: the exact run-1 symptom string is gone (0 occurrences), consistent with the fix changing
that code path — but the new path is worse in aggregate: **10/10 (not 1/10) ended ambiguous**,
and this run never got a single confirmed lock, vs run 1's 9/10.

## Per-attempt breakdown (measured from the log, 1:1 with the 10 `PurchaseRequest` rows)

- 9 attempts: `>>> WARN: L2 funds-lock outcome ambiguous; reservation retained for Hydra
  reconciliation | "Hydra transaction <hash> was not confirmed within 30000ms"` — a client-side
  wait timeout (the service submitted a tx and gave up waiting for it to confirm after 30s).
- 1 attempt (`requestId cmu718ok9000m3eucouwfhfp4`, `intendedTxHash
  3e3c802f24a86fc756d5635ac63df66d12047a1f7ac0e86291398205a6f979ee`): `>>> WARN: L2 funds-lock
  outcome ambiguous; reservation retained for Hydra reconciliation | "Transaction is invalid:
  ConwayMempoolFailure \"All inputs are spent. Transaction has probably already been
  included\""` — a real ledger-level rejection, consistent with a retry reusing an
  already-spent input (i.e. an earlier attempt for the same reservation likely DID land on-chain,
  and a subsequent resubmission collided with it).

**On-chain vs DB-recorded mismatch (measured, direct chain query):** `GET
:4001/snapshot/utxo` shows **9 real UTxOs at the escrow script address**
(`addr_test1wpme53nmdn0hfa5uuv6c75pq8ftjf0ctpq43pgdwqsku39s8hqlh5`) right now — i.e. 9 of the 10
attempted lock transactions DID land on the head as genuine escrow script UTxOs. The DB agrees
with none of them: all 10 `PurchaseRequest` rows sit at `NextAction.requestedAction =
FundsLockingInitiated`, each with a `currentTransactionId` pointing at a `Transaction` row whose
`status = Pending` and `txHash IS NULL` (i.e. a placeholder reservation was created for every
attempt, but never updated with the confirmed hash — for 9 of them despite the underlying tx
genuinely confirming on-chain).

**Cause: labelled measured vs guessed.**
- MEASURED: none of the coordinator's named alternate symptoms appear — 0 occurrences of `L2
  funds-lock failed before submit reservation`; the funding preflight passed (`in-head: buyer
  50000000 (need 45000000), seller 20000000`, logged before Phase A even started), so this is
  not a wallet/UTxO-eligibility or collateral shortfall; and it is not a Phase A *bench* timeout
  either — the bench's own tick budget is `N*3+10=40` ticks and it only needed ~9-10 rounds (one
  lock attempt gated the wallet per round, "head is open but its wallet is busy" appearing for
  the other pending requests each round) before its `done` counter (which counts
  `FundsLockingInitiated` as "past Requested") reached 10 and Phase A's tick loop exited on its
  own — the timeout is inside the *product* code's own 30000ms confirmation wait, not the bench.
- GUESSED (not verified against source — the fix files were not read or touched, per
  instruction): the product fix appears to have replaced the old silent DB-persistence-failure
  path with an explicit "ambiguous, awaiting reconciliation" path that (a) now fires on nearly
  every attempt instead of rarely, and (b) still never resolves the ambiguity even when the
  underlying tx did confirm (9/10 UTxOs are real and on-chain, yet none were reconciled back to
  their `PurchaseRequest` row before the bench gave up). Whether the 30s wait window, the
  confirmation-detection mechanism itself, or the "reconciliation" step that is supposed to
  follow up is the actual defect cannot be determined from this log alone. Not investigated
  further — no product code was read or changed, per instruction.

Also present in the log (not investigated, likely unrelated/pre-existing): a repeated
`fetchCostModels returned an invalid value, using default cost models: []` line before every
attempt, and the known harmless `maxTxExecutionUnits.memory is 14000000, expected 16500000`
warning (documented in prior sessions as not breaking anything).

## Consequence for settle

9 real escrow script UTxOs are left in the head, none resolvable by the drain step's DB-driven
services (they are not in a `FundsLocked`-or-later state the drain passes act on — same "orphan"
category as run 1's leftover datum outputs, just genuine escrows this time). 9 ≤
`DRAIN_MAX_SCRIPT_UTXOS` (10, the same gate that passed 6 orphans through in run 1) and well
under the ~28-UTxO ceiling established in the 2026-08-28 fanout ExUnits incident, so settling was
judged safe to proceed per the existing, already-validated gate — see the main report's
Phase B settle section for the actual outcome.
