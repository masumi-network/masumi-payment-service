# Milestone 4: performance retention (preprod)

Measured during the Milestone 4 integration runs on hydra-node 2.4.1, same method as the Milestone 3 report. This is run 2: a fresh head (`f5cf7f97f1f4416e7a30c7d08fa7a09596946fa067241d418c94334d`) with enough free in-head ADA (108.26) to carry the sustained leg, unlike run 1.

| Metric | Target | Measured |
|---|---|---|
| Per-payment finality p50 | < 500 ms | 37.7 ms |
| Per-payment finality p95 | — | 46.2 ms |
| Sequential run confirmed | — | 200/200 |
| Sustained run confirmed | — | 10000/10000 (511.2 TPS confirmed) |
| Escrow lifecycles | — | 0/10 — bench aborted after Phase A (`FATAL Error: no locks succeeded`); no submit/collect ops/sec available (Phases B and C never ran). See `escrow-latest/NOTE.md` and `escrow-latest/escrow-run2-full.log`. |
| Transaction cost reduction | 95 % | **99.81 %** — see COST.md |

Raw results: `raw-latest/latency/result.json` (latency leg), `raw-latest/sustained/result.json` (sustained leg). Escrow bench: `escrow-latest/` (no `result.json` — the bench never reached that point this run).

The cost figure is the head's fixed L1 lifecycle fees (init + increment + close + fanout) amortised over every L2 transaction the head carried: 200 (latency leg, confirmed) + 10000 (sustained leg, confirmed) = **10200**. The escrow bench's would-be lock/submit-result/collect transactions are deliberately left out of this denominator — it aborted after Phase A with 0 confirmed and no reliable count to add.

Run 1, for transparency: on a head that carried only 200 L2 transactions (the sustained leg failed its own precheck — insufficient free in-head ADA), the measured cost reduction was 88.31 % (`COST.run1-200tx.md`), with latency p50 41.1 ms / p95 52.6 ms (`raw-run1/`).
