# Milestone 4: transaction cost reduction (preprod)

| Quantity | Value |
|---|---|
| Baseline: fee of one real L1 escrow lock (`45ad6d4453e24e84…`) | 207961 lovelace |
| Head lifecycle L1 fees (init + increments + decrements + close + fanout) | 4862007 lovelace |
| L2 transactions carried by that head | 200 |
| Amortised L1 cost per L2 transaction | 24310 lovelace |
| In-head fee per L2 transaction | 0 lovelace (fee forced to zero) |
| **Cost reduction** | **88.31 %** |

Fees are read from Blockfrost for each hash; nothing is estimated.
