# Milestone 4: transaction cost reduction (preprod)

| Quantity | Value |
|---|---|
| Baseline: fee of one real L1 escrow lock (`45ad6d4453e24e84…`) | 207961 lovelace |
| Head lifecycle L1 fees (init + increments + decrements + close + fanout) | 3959522 lovelace |
| L2 transactions carried by that head | 10200 |
| Amortised L1 cost per L2 transaction | 388 lovelace |
| In-head fee per L2 transaction | 0 lovelace (fee forced to zero) |
| **Cost reduction** | **99.81 %** |

Fees are read from Blockfrost for each hash; nothing is estimated.
