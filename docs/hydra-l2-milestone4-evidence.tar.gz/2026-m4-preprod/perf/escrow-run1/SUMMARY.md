# Masumi escrow e2e bench — preprod — 2026-09-18T13:23:43.207Z

| metric | value |
|---|---|
| escrow lifecycles completed | 9/10 |
| locks/sec | 0.26 (9 in 35.2s) |
| submit-results/sec (Plutus) | 0.45 (9 in 19.9s) |
| collects/sec (Plutus) | 0.13 (9 in 72s) |
| escrow txs/sec (active) | 0.21 |
| lifecycles/sec (active / incl. cooldown) | 0.071 / 0.031 |
| contract cooldown wait | 166.8s (configured parameter, not infra) |
| driven by | masumi production services (same code the crons run) |
| hardware | Apple M4 (10 cores), darwin arm64 |
