# Hydra L2 benchmark: latency, 2026-09-18T14:01:37.829Z

| metric | value |
|---|---|
| transactions sent / valid / confirmed | 200 / 200 / 200 |
| **TPS (snapshot-confirmed)** | **25.5** |
| TPS (node-validated) | 25.6 |
| latency to confirmed p50 / p95 / p99 (ms) | 37.7 / 46.2 / 51.3 |
| latency to valid p50 / p95 / p99 (ms) | 8.9 / 16 / 20.5 |
| snapshots (avg txs each) | 200 (1) |
| invalid | 0 |
| config | 1 chains × 200 hops, window unbounded, 1-in/1-out ada transfer, fee 0, no scripts |
| hydra-node | 2.4.1-099f5dd775d8640047d0074edef294c1b39a600d, 2-party head |
| hardware | Apple M4 (10 cores, 16 GB), darwin arm64 |

> Sequential round-trips: each payment waits for multi-signed snapshot
> confirmation before the next is sent, so this is per-payment finality latency.
