# Hydra L2 benchmark: saturation, 2026-09-18T14:01:01.330Z

| metric | value |
|---|---|
| transactions sent / valid / confirmed | 10000 / 10000 / 10000 |
| **TPS (snapshot-confirmed)** | **511.2** |
| TPS (node-validated) | 512.8 |
| latency to confirmed p50 / p95 / p99 (ms) | 962.6 / 1405.2 / 1513.7 |
| latency to valid p50 / p95 / p99 (ms) | 487 / 883.1 / 969.4 |
| snapshots (avg txs each) | 58 (172.4) |
| invalid | 0 |
| config | 40 chains × 250 hops, window 500, 1-in/1-out ada transfer, fee 0, no scripts |
| hydra-node | 2.4.1-099f5dd775d8640047d0074edef294c1b39a600d, 2-party head |
| hardware | Apple M4 (10 cores, 16 GB), darwin arm64 |

> Latency here is measured **under saturation**, with 500 transactions in
> flight. That queue sets the wait, not the head: by Little's Law it is about
> window / TPS. Use a `--mode latency` run for the per-payment finality figure.
