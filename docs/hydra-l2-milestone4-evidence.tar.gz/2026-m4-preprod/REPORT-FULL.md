# Masumi on Hydra L2: Milestone 4 report (preprod)

> Full-length version of `docs/hydra-l2-milestone4-report.md`, which is the condensed report. Links in this file are relative to the repository's `docs/` folder.

**Date:** 2026-09-18, identity run 2026-09-19 · **Network:** Cardano preprod · **hydra-node:** 2.4.1 · **Service:** masumi-payment-service, branch `hydra/m4-preprod-evidence` at commit `610c1b5d`, plus the product fixes listed in Section 2, which are committed together with this report.

Milestone 4 asked for the Layer 2 built in Milestone 3 to be integrated with the Masumi
network so that L2 use is indistinguishable from L1 through the existing tools. This
report covers the testnet evidence gathered for that integration. Mainnet, the video, and
the developer documentation were removed from this report's scope by the project's
decision. The independent security audit is performed by an
external company and is out of scope here.

**Evidence files.** Every evidence file named in this report is inside one archive,
[hydra-l2-milestone4-evidence.tar.gz](hydra-l2-milestone4-evidence.tar.gz) (46 evidence files, plus this full report). Paths such as
`settlement/SUMMARY.md` are relative to the archive's `2026-m4-preprod/` folder. The 50
settlement transactions are also listed with their Cardanoscan links in Appendix A of this
report.

## 1. Settlement verification

**Result: 50 of 50 settlement transactions valid on chain, all heads conserve funds, series is consecutive.**

Every transaction was requested through the payment service's own API (`hydra/head/topup`,
`hydra/head/withdraw`, `hydra/head/close`, `hydra/head/fanout`), confirmed by the service's
own reconciliation, then checked independently on Blockfrost. The run used four heads.

| Heads | Deposits | Withdrawals | Closes | Fanouts | Total | Valid on chain |
| ----- | -------- | ----------- | ------ | ------- | ----- | -------------- |
| 4     | 8        | 34          | 4      | 4       | 50    | 50             |

Full table with Cardanoscan links: Appendix A (copied from `settlement/SUMMARY.md`).
Per-head fund conservation is in the same file; every delta is zero. Head 1's conservation
figure includes 73,000,000 lovelace carried in from a first attempt on the same head — four
transactions, verified on chain and listed in `SUMMARY.md` as not counted in the series —
because that attempt stopped at its third withdrawal, left the head open, and the head was
reused for the counted series.

## 2. Product defects found and fixed during the run

The plan began as evidence-only. On 2026-09-17 the project authorized product fixes for
defects the live run exposed. Each fix below was reviewed. Where a fix has
unit tests in this commit, the existing spec file that carries them is named.

1. The close transaction hash stayed unrecorded on hydra-node 2.3.0 and 2.4.1 because the
   code that reads head state looked for the chain-state field at the top level of the
   node's response, while the node nests it one level down. Fixed in
   `src/lib/hydra/hydra/head-output-tx.ts`; tested in `head-output-tx.spec.ts`.
2. The step that splits a wallet UTxO before a top-up could reuse an exact-amount UTxO that
   carried a datum; hydra-node refuses to commit a UTxO that carries a datum and returned
   an opaque HTTP 400 error. Fixed in `src/services/hydra-topup/pre-split.ts`.
3. In the evidence harness (not product code), the script that opens a head
   (`00-open-head.mts`) re-drafted a second deposit after wrongly concluding that the first
   one had never appeared.
4. A withdrawal could be accepted while the previous withdrawal on the same head was still
   pending, so its in-head split never confirmed. A withdrawal request now receives an
   HTTP 409 error before any split is attempted if a previous one is still pending. Fixed
   in `src/services/hydra-decommit/execute.ts`, `src/lib/hydra/hydra/head-output-tx.ts`,
   `src/lib/hydra/hydra/node-control-queries.ts`, and `src/lib/hydra/hydra/node.ts`; tested
   in `execute.spec.ts` and `head-output-tx.spec.ts`. The guard was later refined so that a
   withdrawal counts as pending only while a decommit transaction is set or the chain's
   version number is at or below the last confirmed snapshot version — otherwise the guard
   itself would deadlock the head. It was refined again so that when neither signal can be
   read at all, the withdrawal is no longer treated as pending forever; that case is now
   logged and resolved as not pending instead.
5. After the service reloaded a saved snapshot (a recovery step), the node would
   re-deliver the identical signed snapshot a second time; the code that replays node
   history rejected the repeat as "replayed or regressed" and the session ended. An
   identical re-delivery is now ignored; anything that is not identical is still rejected.
   Fixed in `src/lib/hydra/hydra/node-history-replay.ts`.
6. A withdrawal for an amount the wallet already held exactly always split funds inside the
   head, even when a UTxO of that exact amount already existed. Fixed in
   `src/services/hydra-decommit/execute.ts`; tested in `execute.spec.ts`. The reused UTxO
   must also be pure ADA: one that happened to hold the exact lovelace plus a native asset
   is not picked by this shortcut. The older selection path, which takes whole outputs when
   they add up to the requested amount, does not yet prefer asset-free outputs; that is
   listed under known limits.
7. The lookup that matches a withdrawal to its settled Layer 1 transaction could return the
   most recent Layer 1 payout with a matching value, so two different withdrawals could be
   recorded against the same Layer 1 transaction hash. The lookup is now bounded from the
   withdrawal's creation time (not its approval time, which can be backfilled after the
   payout itself and hide every genuine match), excludes hashes already claimed by another
   withdrawal, and takes the oldest match. Fixed in `src/services/hydra-decommit/l1-payout.ts` and
   `src/services/hydra-decommit/payout-lookup.ts`; tested in `l1-payout.spec.ts`.
8. Since the hydra-node 2.4.1 upgrade, submitting a transaction waits for the confirmed
   snapshot before returning. As a result, every L2 lock and every L2 escrow action logged
   a false error ("accepted but transaction hash persistence failed; reservation
   retained") even though the underlying database row was already correct: the part of the
   code that listens for confirmation events marked the row confirmed about 70-130
   milliseconds before the part that finalizes the submission ran, and the finalize step's
   check for a "pending" row then matched nothing. This was a bookkeeping error only; no
   funds were at risk. It was measured on 6 of 6 L2 transactions logged during the
   API-compatibility run (Section 4). The finalize step now accepts a row that is either
   pending or already confirmed for the same request and intended transaction hash (a row
   that was rolled back is still excluded), and the lock path now returns early if the
   confirmation listener already updated the row; the lock path's error log now keeps the
   detail that was previously discarded. Fixed in
   `packages/payment-source-v2/src/services/l2-submission/index.ts` and
   `packages/payment-source-v2/src/services/purchases/batch-payments/l2-lock-execute.ts`.
   This commit carries no unit test for this fix (no existing spec file reaches the lock
   path); it was checked live, as described next. A live validation of this fix on preprod was attempted and was
   inconclusive: no lock was accepted in that run, for the reason given in Section 7, so the
   fixed code path was never reached. A separate investigation of that run confirmed the fix
   did not contribute to the failure — that code only runs after a submission returns, and
   none did. The identity run in Section 5 then ran the fixed code on preprod: the
   persistence failure that was logged on 6 of 6 in-head transactions before the fix was
   logged on 0 of 6 (two locks, two result submissions, two collections). The service log is
   not published; the counts are recorded in
   `identity/NOTE.md`. The log
   does not record which branch the finalize step took.

## 3. Performance retention

The latency target below applies to L2 transactions. The 50 settlement transactions in
Section 1 are L1 transactions by nature — that is why they appear on Cardanoscan — and take
L1 confirmation time; they should not be compared to the figures below.

| Metric                     | Target   | Measured (run 2)                          |
| -------------------------- | -------- | ----------------------------------------- |
| Per-payment finality p50   | < 500 ms | 37.7 ms                                   |
| Per-payment finality p95   | —        | 46.2 ms                                   |
| Sequential run confirmed   | —        | 200/200                                   |
| Sustained run confirmed    | —        | 10000/10000 (511.2 TPS confirmed)         |
| Transaction cost reduction | 95 %     | **99.81 %** (over 10,200 L2 transactions) |

Method and raw data: `perf/SUMMARY.md`,
`perf/COST.md`.

The cost reduction is calculated by dividing a head's Layer 1 lifecycle fees (funding,
initialization, deposits and withdrawals, close, and fanout — each fee read directly from
Blockfrost) by the number of L2 transactions that head carried, then comparing that
amortized per-transaction cost against the fee of one real L1 escrow lock measured in the
API-compatibility run (Section 4). Because the reduction depends on how much L2 traffic a
head carries, at the fees measured in this run a head needs to carry about 470 L2
transactions to cross 95 %.

A second run is shown for transparency:
`perf/COST.run1-200tx.md`.
It shared its head with the API-compatibility matrix, so its sustained leg could not start
(71.9 ADA free in the head, 80 needed) and the head carried only 200 L2 transactions; its
cost reduction was 88.31 %, with latency p50 41.1 ms and p95 52.6 ms.

### Escrow lifecycle (lock, submit result, collect)

Run 1, on head `5b307078…`: 9 of 10 lifecycles completed. Rates:
`perf/escrow-run1/SUMMARY.md` —
locks 0.26/s, result submissions 0.45/s, collections 0.13/s. The tenth purchase never
locked: no reservation row was created for it in the database, and the cause was not
established.

Run 2, on a head that had just carried 10,200 L2 transactions: all 10 lock attempts ended
in an "outcome ambiguous" state and 0 of 10 registered as locked by the benchmark's
metric — 9 were not confirmed within the service's 30-second wait, and 1 failed because its
inputs were already spent. A direct query of the head's own UTxO set showed that 9 of the
10 lock transactions had in fact been confirmed inside the head; the database reservations
stayed pending for all 10. The 9 confirmed escrow UTxOs went through fanout to Layer 1 and
remain at the contract address (test funds, not recovered). The cause was measured after
this run and is described in Section 7. Evidence:
`perf/escrow-latest/NOTE.md`.

### Settlement of the two benchmark heads

These four transactions are additional public evidence; they are not part of the 50
settlement transactions in Section 1.

- Run 1: close [`c7f09b403e894435…`](https://preprod.cardanoscan.io/transaction/c7f09b403e894435474f4be2c1212a923826f353b6271f7bc986b1694b2a23a5),
  fanout [`92dff8499053f3e6…`](https://preprod.cardanoscan.io/transaction/92dff8499053f3e663b37c86e4859689f4c16f29deae99a53ce3c1ce60184124)
- Run 2: close [`1f1fc6f2dc78f7ed…`](https://preprod.cardanoscan.io/transaction/1f1fc6f2dc78f7edc4b8a1d9365d43d2da493952ed482f64ccf4eab1b8c9f11e),
  fanout [`7ed322adfe9eeb7c…`](https://preprod.cardanoscan.io/transaction/7ed322adfe9eeb7c715617e5c48aa50bb82dd3abbb3ccb6cf45f1c6b22987e5e)

## 4. SDK/API compatibility

The same `POST /payment` and `POST /purchase` calls ran on L1 and L2 with only the optional
`forceLayer` field changed, and with it omitted the service chose L2 on its own because an
open head existed: `api-compat/MATRIX.md`.
Responses report the layer used in `CurrentTransaction.layer` and the head in
`CurrentTransaction.hydraHeadId`.

| Case               | forceLayer sent | Layer chosen by the service | State       | Tx                                                                                                                                 |
| ------------------ | --------------- | --------------------------- | ----------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| forceLayer L1      | `"L1"`          | L1                          | FundsLocked | [`45ad6d4453e24e84…`](https://preprod.cardanoscan.io/transaction/45ad6d4453e24e84d2de656eda71d6f4d7ad278b3b19127af80cdb0a90fcc43e) |
| forceLayer Hydra   | `"Hydra"`       | L2                          | FundsLocked | `38abe5dc99f94fcf…` (in-head; not on Cardanoscan)                                                                                  |
| forceLayer omitted | `null`          | L2                          | FundsLocked | `c2515612d5180e06…` (in-head; not on Cardanoscan)                                                                                  |

The final case data is in
`api-compat/cases.json`
(attempt 4). Three earlier attempts are kept unedited alongside it
(`cases.attempt1.json` through `cases.attempt3.json`): two failed because of defects in the
evidence script itself — it read two purchase fields from a response that does not carry
them, and its status poll used a list endpoint whose default filter only returns
Web3CardanoV1 records — and one failed because the buyer's in-head funds were spread across
UTxOs and the lock needed a second one, fixed by funding a separate UTxO.

Integrators should note that `GET /registry`, `GET /purchase`, and `GET /payment` default
to a Web3CardanoV1 filter; a V2 caller must pass `filterPaymentSourceType=Web3CardanoV2`.

A result was submitted for all three cases. The L1 case reached `ResultSubmitted`. The two
L2 cases did not: the selling side's in-head result submission was deferred on every check
until the deadline passed, and the buyer's refund then ran as designed, returning funds to
the buyer inside the head with no escrow left behind. The most likely cause, inferred but
not proven, is that the selling wallet held no funds inside the head during this run and so
could not build the in-head transaction. The full lock, submit-result, and collect sequence
is demonstrated in Section 3's escrow benchmark, where the seller is funded inside the
head. The identity run in Section 5 repeated these calls with the selling wallet funded
inside the head, and both Layer 2 purchases reached `ResultSubmitted` and were then
collected.

## 5. Identity retention on L2

An agent's identity in Masumi is its registry NFT, referred to as the `agentIdentifier`,
together with the KERI-ACDC verification claims attached to it at registration. In-head
transactions never appear on a public explorer, so the question for Layer 2 is whether a
payment made inside a head stays tied to that identity. The service keeps that tie in its
own records, and this section exports it.

One agent was registered through `POST /registry` with a KERI-ACDC claim, and its NFT was
minted on preprod: [`01a02e927791023a…`](https://preprod.cardanoscan.io/transaction/01a02e927791023a9af3f1ec95bba37157cf0106c285ff1a9d3dff30f96f907b). Two
purchases for that agent were made with the unchanged `POST /payment` and `POST /purchase`
calls, locked inside an open head, had a result submitted, and were collected, all inside
the head. `identity/AUDIT-LOG.md`
lists the resulting 6 in-head transactions, a lock, a result submission and a collection for
each purchase, in 12 rows, because each transaction is recorded once on the buyer's purchase
and once on the seller's payment. The two locks are named in
`identity/run/cases.json`,
and the export taken after the result submissions and before the collections is
`identity/run/audit-log.after-submit.json`.
Every row carries the agent identifier, the head it ran in, and the issuer AID, holder AID
and credential SAID registered for that agent. The agent identifier on a payment can also be
decoded from the payment's `blockchainIdentifier`, which embeds the agent identifier
together with the selling wallet's signature over the payment terms, and those signed terms
include the agent identifier, so the tie does not rest on a free-text field. That signature
is produced when the payment is created and checked when the purchase is created; the
in-head transactions carry the same request record and do not re-verify it. Decoding the two
`blockchainIdentifier` values in this evidence gives the exported agent identifier in both
cases; the check is recorded in
`identity/NOTE.md`.
The head's own Layer 1 transactions are in
`identity/l1-anchors.json`,
and what was run, step by step, is in
`identity/NOTE.md`.

No identity code was changed for this milestone; the export script only reads.

## 6. Wallet operations on L2

Funds move into a head with `hydra/head/topup`, out of it with `hydra/head/withdraw`, and
the in-head balance is read with `hydra/head/balance`; payments and collections are the
existing payment and purchase endpoints. Section 1 exercised `hydra/head/topup` 8 times,
`hydra/head/withdraw` 34 times, `hydra/head/close` 4 times, and `hydra/head/fanout` 4 times.

## 7. Known limits stated for the reviewer

- Fanout evaluates every remaining script UTxO in one transaction, so heads are drained of
  escrows before close.
- The fanout transaction hash is not recorded on the head's own database row by the
  service; this report takes fanout hashes from the chain (head-token anchors).
- A top-up row reads "Absorbed" (documented as spendable on L2) as soon as the service sees
  the increment on Layer 1, but a withdrawal of those funds is refused until the service's
  own hydra-node has observed it too, which can take several minutes. This is conservative,
  but the wording overpromises.
- Not fixed: a withdrawal removes whole outputs from the head. When the outputs the service
  selects add up to exactly the requested ADA amount, they are withdrawn as they are, and
  the selection does not yet prefer asset-free outputs, so an output that also holds a
  native asset can leave the head with a partial ADA withdrawal. A withdrawn output keeps
  its address when it moves to Layer 1, so the asset stays with the same wallet and nothing
  is lost, but it is no longer in the head. The deposits in this report's settlement heads
  were ADA only.
- Not fixed: the guard that checks for a pending withdrawal reads only the service's own
  hydra-node. Each node follows Layer 1 through its own independent Blockfrost poll, so a
  peer node can observe a decrement up to about 20 seconds later than the requesting node.
  A withdrawal requested inside that gap is rejected by the peer node; the requesting node
  keeps the pending withdrawal with no way to cancel it, the withdrawal's database row
  stays pending, and the head refuses further withdrawals until it is closed. This
  happened once, on head 3's 21st withdrawal, 2026-09-18 09:42 UTC; no funds moved, and the
  10 ADA involved returned at fanout. The evidence harness now waits 45 seconds between
  withdrawals to avoid it.
- Upstream hydra-node behavior observed on this two-node, Blockfrost-backed setup: a
  snapshot round can strand after a decrement, when one node has signed a message the peer
  never finished processing. Recovery requires loading a saved snapshot onto both nodes,
  and this is only safe when both nodes report the same confirmed snapshot number; loading
  an older snapshot onto a node that has already signed a newer one desynchronizes the
  head. This ended head 2 early — an operator mistake in the evidence harness's watchdog,
  since corrected.
- Contestation was not demonstrated: on head 2, the peer node attempted to contest with the
  newer snapshot, but the network rejected its transaction because the node's only large
  wallet UTxO carried a native token and collateral inputs may not carry non-ADA value.
  Fanout settled the older snapshot; all funds returned regardless.
- Honest count of requests: the 50 transactions in Section 1 are the settlement
  transactions that reached Layer 1, in order, and all are valid. Several withdrawal
  requests made during the run were refused or did not settle, each traceable to one of
  the defects listed in Section 2; none of them moved funds, and none appears in the
  ledger. Head 1 was closed early by an operator mistake, and head 2 by the watchdog error
  described above, which is why the 50-transaction series spans four heads of unequal
  length.
- Ledger repair on head 1, disclosed: the payout-matching defect described in Section 2
  (item 7) had assigned one withdrawal another withdrawal's Layer 1 transaction hash. That
  row's hash was corrected using the chain's own list of decrement transactions for the
  head, and one withdrawal that had not yet been recorded (because the driving process had
  been stopped) was appended from the service's own database row. A copy of the ledger
  from before this repair is kept alongside it
  (`settlement/ledger.jsonl.before-repair-*`).
- The escrow benchmark clears the purchase and payment database tables when it starts. It
  ran after the API-compatibility matrix on the same database, so the matrix's L1-case
  escrow (5.435 tADA, on-chain in `ResultSubmitted` state — Section 4) can no longer be
  collected by the service; the funds remain at the Layer 1 contract address on preprod.
  The evidence files themselves are unaffected. This was a sequencing mistake in the
  evidence harness, not a product behavior.
- When the selling side cannot build an in-head result submission, the service defers it on
  every check and logs the reason at informational level only, so an operator sees a
  refund at the deadline without an earlier warning.
- In run 1 of the escrow benchmark, one of ten purchases never locked: no reservation row
  was created for it in the database. The cause was not established.
- In run 2 of the escrow benchmark, all 10 lock attempts ended in an "outcome ambiguous"
  state on a head that had just carried 10,200 L2 transactions, although 9 of the 10 lock
  transactions were in fact confirmed inside the head. The 9 confirmed escrow UTxOs went
  through fanout to Layer 1 and sit at the contract address (test funds, not recovered). What
  follows separates two different levels of confidence: the transaction count against this
  record's limit, and the ruling-out of a message-size explanation, were both measured
  directly. That the limit is what actually stopped the confirmations is concluded from the
  code path below, not confirmed by a re-run with the limit raised. The service keeps a
  bounded record, capped at 10,000
  entries (`MAX_UNRECONCILED_CONFIRMED_TRANSACTIONS`,
  `src/lib/hydra/hydra/node.ts`), of confirmed in-head transactions it has not yet folded
  into its own database. The code path that waits for a lock to confirm learns that a
  transaction is confirmed only from that record, which is filled by the service's own
  verified replay of the head's history, not by its live connection to the head. In this
  run, a separate raw-throughput benchmark had already pushed 10,251 transactions through
  the same head while the payment service itself was stopped, so the head had no saved
  reconciliation checkpoint and every one of those transactions counted against the record's
  limit. Once the limit was reached, the record stopped accepting new entries and never
  resumed, and nothing was logged when that happened. From that point, every escrow lock in
  this run waited its full 30-second timeout and was reported "outcome ambiguous," even
  though 9 of the 10 had in fact confirmed inside the head. A second explanation — that a
  size limit on the head's message stream was to blame — was ruled out by measurement: the
  head's saved history totalled 22,154 events, the largest 84,933 bytes, far below the
  4-mebibyte limit that would have to be exceeded for that explanation to hold, and no
  message was rejected or connection dropped during the run. A comparison head from run 1,
  which had carried only 275 transactions, completed 9 of 10 escrow lifecycles. No funds
  were at risk in either case: a reservation that cannot be confirmed this way stays pending
  by design, and the escrow outputs that had genuinely landed in the head were returned to
  Layer 1 when the head was closed and fanned out; the effect is that the service stops
  making progress, not that funds are lost or misdirected. In normal operation a background
  job reconciles this backlog in batches, so the 10,000 limit is reached only when that job
  has stalled, when the service is offline while a head keeps transacting, or when the
  service first connects to a head that already has history and no saved checkpoint — which
  is what happened here, because the head was driven directly by a benchmark tool while the
  service was stopped. This is not fixed: the record's limit is reached silently today, with
  no log line or alert. A proposed fix is to log an error when the record stops accepting
  entries and to make a lock fail immediately with the "ambiguous" outcome instead of waiting
  the full 30 seconds. Until then, operators should keep a head's unreconciled backlog well
  below 10,000 transactions and should not drive a head with a tool that bypasses the service
  while the service is stopped.
- The verification claims used in Section 5 are the API's documented example values, and
  their OOBI addresses do not resolve. Section 5 shows that the tie between an in-head
  transaction, the agent's registry NFT, and the claims registered with it is kept and can
  be audited. It does not show KERI credential verification, and it was run on testnet only.
- After the Fanout in the identity run, the service's L2 escrow-state reconcile job kept
  polling the finalized head and logged a warning (`[HydraReconcile] Failed to reconcile
head`, with an HTTP 404 from the hydra-node) about every five seconds, 19 times in the 90
  seconds until the service was stopped. No effect on funds or on the exported records was
  observed. The cause was not investigated.

## Replication

Run the API-compatibility matrix and the escrow benchmark on separate databases or heads;
running them on the same database strands the escrow described above.

- [`hydra-l2-flow/18-settlement-run.sh`](../hydra-l2-flow/18-settlement-run.sh) — the driver applies one `WITHDRAWALS` value per invocation, and this run invoked it once per head with a different value each time (the script is resumable and skips a head whose fanout row is already in the ledger), giving 5, 5, 20, and 4 settled withdrawals on heads 1-4 (see Section 1). Every invocation otherwise used `DEPOSITS=2 DEPOSIT_LOVELACE=40000000 WITHDRAW_LOVELACE=3500000`, a 120-second deposit activation delay, and a 600-second deposit period.
- [`hydra-l2-flow/19-verify-settlement-ledger.mts`](../hydra-l2-flow/19-verify-settlement-ledger.mts)
- [`hydra-l2-flow/21-api-compat-matrix.sh`](../hydra-l2-flow/21-api-compat-matrix.sh)
- [`hydra-l2-flow/20-identity-audit-log.mts`](../hydra-l2-flow/20-identity-audit-log.mts) — read-only; needs an agent registered with `verifications` and at least one in-head purchase for it. The identity run made its purchases with `M4_MATRIX_CASES=l2 M4_MATRIX_OUT=<dir> ./hydra-l2-flow/21-api-compat-matrix.sh`, with the buyer and the selling wallet both funded inside the head. It writes `identity/AUDIT-LOG.md` and `identity/audit-log.json` in place; set `M4_EVIDENCE_ROOT` to a scratch directory to keep the published evidence intact.
- [`hydra-l2-flow/22-cost-reduction.mts`](../hydra-l2-flow/22-cost-reduction.mts)
- [`hydra-l2-flow/replicate-benchmark.sh`](../hydra-l2-flow/replicate-benchmark.sh)

`HYDRA_SCRIPTS_TX_IDS` must point at a published hydra-node 2.4.1 script set; the driver
carries the one used for this run. Prerequisites are otherwise those of
[the Milestone 3 report](hydra-l2-benchmark-report.md#replication).

## Appendix A. The 50 settlement transactions

Copied without change from `settlement/SUMMARY.md` (generated 2026-09-18T11:16:45.538Z by
`hydra-l2-flow/19-verify-settlement-ledger.mts`, which checks every hash on Blockfrost).

| #   | Head | Kind       | Tx                                                                                                                                 | Block   | Valid |
| --- | ---- | ---------- | ---------------------------------------------------------------------------------------------------------------------------------- | ------- | ----- |
| 1   | 1    | deposit    | [`e9efa30047ff056d…`](https://preprod.cardanoscan.io/transaction/e9efa30047ff056ddfc195e3316a68ae88b371bb6ae50c644b813e252910ffc4) | 5190222 | yes   |
| 2   | 1    | deposit    | [`7e17f463b014ba78…`](https://preprod.cardanoscan.io/transaction/7e17f463b014ba7832c4ebc2d2fee41a476c23aa44506b299b4aecaba39bc2bc) | 5190250 | yes   |
| 3   | 1    | withdrawal | [`32b605bbab4c1d26…`](https://preprod.cardanoscan.io/transaction/32b605bbab4c1d266c70b0cb20d95d6d568d22a5c3c4e22e1e31ade03b21e28a) | 5190367 | yes   |
| 4   | 1    | withdrawal | [`109dc4402014091e…`](https://preprod.cardanoscan.io/transaction/109dc4402014091ebe02b5d542009bb9aa52e5e275a4262ae145b68fe2e533f1) | 5190411 | yes   |
| 5   | 1    | withdrawal | [`d2f6d1c24dd0fda3…`](https://preprod.cardanoscan.io/transaction/d2f6d1c24dd0fda3ee0c43490771a6ff0b51ee1584bde6aa7021880a6c36ee62) | 5190413 | yes   |
| 6   | 1    | withdrawal | [`5cfc97beda534290…`](https://preprod.cardanoscan.io/transaction/5cfc97beda534290bf17d00a55c75dc050c17d966c154892819f9deb3de89de3) | 5190417 | yes   |
| 7   | 1    | withdrawal | [`2908957862921aa9…`](https://preprod.cardanoscan.io/transaction/2908957862921aa9eba6290b3018b25e1e62b426cd205e0d1cc613a845e26916) | 5190467 | yes   |
| 8   | 1    | close      | [`cf73c50ffaa4e9e2…`](https://preprod.cardanoscan.io/transaction/cf73c50ffaa4e9e25fca8d0d30bb461ac9dfc7b09e1d050aedb34c07214898fa) | 5190483 | yes   |
| 9   | 1    | fanout     | [`ce382986026183a0…`](https://preprod.cardanoscan.io/transaction/ce382986026183a04e6276adda55637497f5042ac90f9a79f74f034d7c5c6001) | 5190506 | yes   |
| 10  | 2    | deposit    | [`686f58d33391aa0f…`](https://preprod.cardanoscan.io/transaction/686f58d33391aa0f08bee4e3b9644cad682254f83e296504dbfc79a98ef37017) | 5190539 | yes   |
| 11  | 2    | deposit    | [`c2b3721e77ef0363…`](https://preprod.cardanoscan.io/transaction/c2b3721e77ef036308484f339be2c19f5057a91cc766893e1f251d4231bdd7f0) | 5190559 | yes   |
| 12  | 2    | withdrawal | [`e604b4331d89a740…`](https://preprod.cardanoscan.io/transaction/e604b4331d89a7404edda7750ca6a9bb87d6e48536b6ad304868b63f7463f077) | 5190585 | yes   |
| 13  | 2    | withdrawal | [`64d74fbfa796de7e…`](https://preprod.cardanoscan.io/transaction/64d74fbfa796de7ed2c42bedb85e96180e0ce2323acd1bff9717e69773a9478d) | 5190595 | yes   |
| 14  | 2    | withdrawal | [`6b06388f4fff4d78…`](https://preprod.cardanoscan.io/transaction/6b06388f4fff4d78e8aeb78dbf570b45858a6b38b40a03f8337be008535c80ac) | 5190599 | yes   |
| 15  | 2    | withdrawal | [`4dc46cbfb2e2d2e7…`](https://preprod.cardanoscan.io/transaction/4dc46cbfb2e2d2e7e34781bbe033f203e7ae6bed9e53521d7cbd5bd1179ccb8a) | 5190603 | yes   |
| 16  | 2    | withdrawal | [`18ec08d6c988086e…`](https://preprod.cardanoscan.io/transaction/18ec08d6c988086e2e5c2806f70eb440bc0646b3d47db70ec1f54020a3c95665) | 5190606 | yes   |
| 17  | 2    | close      | [`4c083d454064f3df…`](https://preprod.cardanoscan.io/transaction/4c083d454064f3dfb173a5ebf59688bb3a82c8f3e19d4cd0e6835ad8c139446a) | 5190654 | yes   |
| 18  | 2    | fanout     | [`bdb080f5a8686b05…`](https://preprod.cardanoscan.io/transaction/bdb080f5a8686b05e608e503f35b74d23a296a909b8a3df4ef11381a373537be) | 5190680 | yes   |
| 19  | 3    | deposit    | [`769f3dc21ec45831…`](https://preprod.cardanoscan.io/transaction/769f3dc21ec458310499cb5008dc492a60db420a6eb2d89ac11c728f581f5e91) | 5190821 | yes   |
| 20  | 3    | deposit    | [`0bde269563a2f2a2…`](https://preprod.cardanoscan.io/transaction/0bde269563a2f2a292bdf8e25d9ccd75919ed3a23039b5b8cbfd3ebc134181e4) | 5190838 | yes   |
| 21  | 3    | withdrawal | [`99d8e5f471141f51…`](https://preprod.cardanoscan.io/transaction/99d8e5f471141f514f6377f51bcc2196616ffc189977b684888fdbb26dc8262a) | 5190861 | yes   |
| 22  | 3    | withdrawal | [`4f3d9b84bbfaec72…`](https://preprod.cardanoscan.io/transaction/4f3d9b84bbfaec721c8475eefdd058d86711f019a0b862b9954498c7585c50f8) | 5190865 | yes   |
| 23  | 3    | withdrawal | [`e2ad5a27a40a6ea1…`](https://preprod.cardanoscan.io/transaction/e2ad5a27a40a6ea1b015551c57fa5183d70e8d13ecdaf455574700855665de82) | 5190869 | yes   |
| 24  | 3    | withdrawal | [`a871f2f6a1e55aee…`](https://preprod.cardanoscan.io/transaction/a871f2f6a1e55aee08e0a2ed1ef899da52a5a79079224a02add78c8aca4151e7) | 5190872 | yes   |
| 25  | 3    | withdrawal | [`0be1f53b06eae76b…`](https://preprod.cardanoscan.io/transaction/0be1f53b06eae76b7309c143311c2318f3cb1cb61ecd2d094a2864356269d855) | 5190874 | yes   |
| 26  | 3    | withdrawal | [`93114cc1633c522a…`](https://preprod.cardanoscan.io/transaction/93114cc1633c522a48c85d47a91fda085a3ab0f65284900169e17b22c687b6aa) | 5190877 | yes   |
| 27  | 3    | withdrawal | [`d078d0b67cb2d1d3…`](https://preprod.cardanoscan.io/transaction/d078d0b67cb2d1d37a9392f31b664ccf2dd52dbfc5373dd2de392c8d85efe58c) | 5190883 | yes   |
| 28  | 3    | withdrawal | [`4eb8d07e0253c754…`](https://preprod.cardanoscan.io/transaction/4eb8d07e0253c7544970c6fb8dca8f1ccb82cd2673d5c1952422f020f050f989) | 5190887 | yes   |
| 29  | 3    | withdrawal | [`f65f51bc07c6da7c…`](https://preprod.cardanoscan.io/transaction/f65f51bc07c6da7c3bdec044334045d0d86c78e86d088e4a0ed323fe72d68c7e) | 5190890 | yes   |
| 30  | 3    | withdrawal | [`60506daa9c480d40…`](https://preprod.cardanoscan.io/transaction/60506daa9c480d40d05d4d2689cefada0f1687e539d071367153a8872dad39f7) | 5190892 | yes   |
| 31  | 3    | withdrawal | [`69e15c7be8f0c08b…`](https://preprod.cardanoscan.io/transaction/69e15c7be8f0c08b180819a467da5e268bad592d18b4dfc367f045c82d61685a) | 5190894 | yes   |
| 32  | 3    | withdrawal | [`2e7a8300c98f77b8…`](https://preprod.cardanoscan.io/transaction/2e7a8300c98f77b89b2f54b54d2b61c62a5ccaae943d860ef1ca69213104a3f0) | 5190898 | yes   |
| 33  | 3    | withdrawal | [`3c5490b29a3ebd93…`](https://preprod.cardanoscan.io/transaction/3c5490b29a3ebd93fb4c6c76f4cfda29fb79f511b61d9c416879ae8b0b37f424) | 5190902 | yes   |
| 34  | 3    | withdrawal | [`be8debec99ab1397…`](https://preprod.cardanoscan.io/transaction/be8debec99ab13973ca3c7266f345e91934ba09a79231225ae797b6dba59fa45) | 5190906 | yes   |
| 35  | 3    | withdrawal | [`fc5d7ef3db695ffb…`](https://preprod.cardanoscan.io/transaction/fc5d7ef3db695ffb60be8ae24bd7ddc1825928fea6ec7a92ba6bede4943cc799) | 5190909 | yes   |
| 36  | 3    | withdrawal | [`c63fb1004209cb19…`](https://preprod.cardanoscan.io/transaction/c63fb1004209cb1947c590b51091a2d65507b92ae13df33fbee09147431f939f) | 5190913 | yes   |
| 37  | 3    | withdrawal | [`db62d92be1d8c6c8…`](https://preprod.cardanoscan.io/transaction/db62d92be1d8c6c889df6fc88b6ab01f050872b45bf5ce0328d12d7477121629) | 5190916 | yes   |
| 38  | 3    | withdrawal | [`7ab5c00494524702…`](https://preprod.cardanoscan.io/transaction/7ab5c004945247026e74be831456f20375d857b198e129f69b471f48cc13a97e) | 5190921 | yes   |
| 39  | 3    | withdrawal | [`26ff7b77ebfe9e76…`](https://preprod.cardanoscan.io/transaction/26ff7b77ebfe9e7615c189d6a2eb92b15636fb45bfc479390283cfd80f17a52b) | 5190924 | yes   |
| 40  | 3    | withdrawal | [`9d02d7acc27da296…`](https://preprod.cardanoscan.io/transaction/9d02d7acc27da296b8dfcb5bc1847e6aed728acebb493eb8bddb9cb0b73d6e97) | 5190926 | yes   |
| 41  | 3    | close      | [`3e62703a9825b5ca…`](https://preprod.cardanoscan.io/transaction/3e62703a9825b5ca9854cb9742e06e4a541a06b8f7fa77bc3e0ab6fe3fa87121) | 5190996 | yes   |
| 42  | 3    | fanout     | [`4c6cb1602ceb23ac…`](https://preprod.cardanoscan.io/transaction/4c6cb1602ceb23acc7aa7b3e2f38c928fc5bae069a9545d90615e212035458e8) | 5191014 | yes   |
| 43  | 4    | deposit    | [`11f343fbd16eb704…`](https://preprod.cardanoscan.io/transaction/11f343fbd16eb70499d9ebeb86109538124e58818ece5e8576c7cc79df762814) | 5191054 | yes   |
| 44  | 4    | deposit    | [`a381144f60db3bdc…`](https://preprod.cardanoscan.io/transaction/a381144f60db3bdcc3876330f44252e9972ccbb81faa7c8a9835f303a0e59492) | 5191072 | yes   |
| 45  | 4    | withdrawal | [`d997b03854a9cd24…`](https://preprod.cardanoscan.io/transaction/d997b03854a9cd244a2e60f24a347bff0aac7924e17420a040212e6e08bdf61e) | 5191096 | yes   |
| 46  | 4    | withdrawal | [`670ef56b0eb62468…`](https://preprod.cardanoscan.io/transaction/670ef56b0eb624680c05d1a7a9563aade43ec9e0a3ec00368e4c93dcd8269b90) | 5191102 | yes   |
| 47  | 4    | withdrawal | [`2902e4b5d9b8ef69…`](https://preprod.cardanoscan.io/transaction/2902e4b5d9b8ef69c3229eb55cfc86eee545c8d5e1ad40b705bd76434549d621) | 5191108 | yes   |
| 48  | 4    | withdrawal | [`631b12084cac1f65…`](https://preprod.cardanoscan.io/transaction/631b12084cac1f658d8e4105c7814e52466bb01a0ebde98b3a834dfb9b6a39a0) | 5191113 | yes   |
| 49  | 4    | close      | [`eaff40369a1e3718…`](https://preprod.cardanoscan.io/transaction/eaff40369a1e3718692711d81cef9a9fb0e0545cbde6ff79454d93b4e3ed24b8) | 5191116 | yes   |
| 50  | 4    | fanout     | [`1db38c7583a945ba…`](https://preprod.cardanoscan.io/transaction/1db38c7583a945ba4b6133d60bb937c23688c1db1b95a5e85311fe64593fb666) | 5191148 | yes   |

### Fund conservation per head (lovelace)

| Head | Head id             | Carried in | Deposited | Withdrawn (requested) | Withdrawn (settled on L1) | Fanout to wallet | Delta |
| ---- | ------------------- | ---------- | --------- | --------------------- | ------------------------- | ---------------- | ----- |
| 1    | `3c32def46e0cd7f0…` | 73000000   | 80000000  | 17500000              | 17500000                  | 135500000        | 0     |
| 2    | `b505b683e46d601d…` | 0          | 80000000  | 17500000              | 17500000                  | 62500000         | 0     |
| 3    | `0fd5c50edc35de3f…` | 0          | 80000000  | 70000000              | 70000000                  | 10000000         | 0     |
| 4    | `efebfb67e077d6c9…` | 0          | 80000000  | 80000000              | 80000000                  | 0                | 0     |

Delta is carried-in plus deposited minus requested withdrawals minus fanout-to-wallet and must be zero. Requested minus settled is the decommit transactions' own L1 fees.

### Transactions carried into a head (not counted in the series)

These settlement transactions ran on the same head before the counted series began (a first attempt that stopped at its third withdrawal; the head stayed open and was reused, so the funds they left in the head return in that head's fanout).

| Head | Kind       | Tx                                                                                                                                 | Block   | Valid |
| ---- | ---------- | ---------------------------------------------------------------------------------------------------------------------------------- | ------- | ----- |
| 1    | deposit    | [`f243046cf3eef087…`](https://preprod.cardanoscan.io/transaction/f243046cf3eef0876430acb322d24bc602fe2a9de55a42e92c4c5c190bf89895) | 5190104 | yes   |
| 1    | deposit    | [`8c848498a4b84734…`](https://preprod.cardanoscan.io/transaction/8c848498a4b84734e0eec8d90f8f167ae66a2a94ba2b49de67a530d8e8d46ef5) | 5190130 | yes   |
| 1    | withdrawal | [`07723219ebc937eb…`](https://preprod.cardanoscan.io/transaction/07723219ebc937eb2627dab115fe347f8ccee3c17895d7a6797b8e675a775585) | 5190147 | yes   |
| 1    | withdrawal | [`b79b4e46148f0de9…`](https://preprod.cardanoscan.io/transaction/b79b4e46148f0de9d4dec96f250639febaa2549f328431a229bde951014e62fd) | 5190152 | yes   |

Every hash above is selected by the head token policy in `head-N/l1-anchors.json`; no L1 address query is involved.
